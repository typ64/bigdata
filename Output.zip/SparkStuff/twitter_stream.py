from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
import time
import re
import json

ckey = 'vycp6RSNJY2lthvli3KXdcq4B'
csecret = 'X2ocS3NQ4HFejA1MkOO1i1XG61pA7PfrE4fVQfVGXDqFwCJemF'
atoken = '905551340180529152-P5aO6UedpikHMI71cHcayH3FURNz1xw'
asecret = '3njXr7VZIumligKwv107UbAbJZ1NVYT35r1YJZ2yOh9cW'

class listener(StreamListener):

	def __init__(self, api=None):
		super(listener, self).__init__()
		self.num_tweets = 0
		
	def on_data(self, data):
		try:
		
			self.num_tweets += 1
			if self.num_tweets < 10:
				tweet = data.split(',"text":"')[1].split(',"source":"')[0]
				print tweet
				saveThis = str(time.time()) + '::::' + tweet
				saveFile = open('data/twitter_data.txt','a')
				saveFile.write(saveThis)
				saveFile.write('\n')
				saveFile.close()	
				return True
			else:
				return False
			
		except BaseException, e:
 			print 'failed ondata_1,', str(e)
			time.sleep(5)

	def on_error(self, status):
		print status

try:
	
	auth = OAuthHandler(ckey, csecret)
	auth.set_access_token(atoken, asecret)
	twitterStream = Stream(auth, listener())
	twitterStream.filter(track=["trump"])
except BaseException, e:
	print 'failed ondata_2,', str(e)
	time.sleep(5)
